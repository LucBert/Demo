# Importo i moduli necessari
import os, shutil, csv, sys, argparse
from pathlib import Path as path

def moveFromFiles(FileName):

    # Assegno alle variabili i relativi path.
    p = path('.') / 'files'
    docs = (p / 'docs')
    images = (p / 'images')
    audio = (p / 'audio')
    
    FileName = path(FileName)
    pathFileName = p / FileName

    # Creo il file recap.csv o se esiste già lo aggiorno, inzializzo l'oggetto writer e scrivo l header solo se non eisiste gia.
    with open (p / 'recap.csv', 'a', newline = '') as csvFile:
        writer = csv.writer(csvFile, delimiter = ',')
        if os.stat(p / 'recap.csv').st_size == 0:
            writer.writerow(['Name','Type','Size(Byte)'])
            
        # Verifico che il nome del file indicato come argomento della funzione sia corretto e eseguo lo spostamento.
        if pathFileName.exists() == True:
            # Distinguo le verie estensioni dei file e li sposto di conseguenza nelle sub-directory
            # di apaprtenenza (se non esistono gia le creo) salvo le informazioni richieste in 
            # una riga del file csv e poi le stampo a video.
            if FileName.suffix in ('.txt','.odt'):
                os.makedirs(docs, exist_ok=True)
                shutil.move(pathFileName, docs)
                writer.writerow([FileName.stem, 'doc', os.path.getsize(p/'docs'/FileName)])

            elif FileName.suffix in ('.jpg','.png','.jpeg'):
                os.makedirs(images, exist_ok=True)
                shutil.move(pathFileName, images)
                writer.writerow([FileName.stem, 'image', os.path.getsize(p/'images'/FileName)])

            elif FileName.suffix == '.mp3':
                os.makedirs(audio, exist_ok=True)
                shutil.move(pathFileName, audio)
                writer.writerow([FileName.stem, 'audio', os.path.getsize(p / 'audio' /FileName)])
                
            return f'{FileName} has been move correctly'
        
        # Se il nome del file non è corretto restituisco a video un messaggio per comunicarlo all'utente
        else:
            return f"{FileName} doesn't exists, please be sure the file you specify have the correct name and extension"
            sys.exit()

# Inizilizzo l'oggetto parser per rendere possibile l'esecuzione del programma da linea di comando indicando una breve descrizione di cosa fa l'eseguibile
# Inoltre aggiungo l'argomento obbligatorio (nome del file completo di estensione) da indicare per esegurie il programma
parser = argparse.ArgumentParser(description = "Move a specify file from the 'files' directory to a realtive sub-direcotry based on extension of file")
parser.add_argument('FileName', type = str, help = "File name with extension you want move from 'files' directory to a realtive sub-directory ")

args = parser.parse_args()

risultato = moveFromFiles(args.FileName)
print(risultato)